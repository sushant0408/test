# Property-Resale-Value-Predictor
A ML based tool that estimates property resale value based on its attributes.
